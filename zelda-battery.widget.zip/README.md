# ubersicht-zelda-battery
Legend of Zelda OoT inspired battery meter for Übersicht.

![screen shot](media/screenshot.png)

# Customization
There is little room for customization (this is a pretty simple widget), but if you wanted to change sizing, spacing, or maybe even the images then open up the index file and look for my comments.
